import React, { useEffect, useState } from 'react';
import API from '../api';

const MedicineList = () => {
  const [medicines, setMedicines] = useState([]);

  useEffect(() => {
    API.get('/medicines').then(res => setMedicines(res.data));
  }, []);

  return (
    <div>
      {medicines.map((med, index) => (
        <div key={index}>
          <h3>{med.name}</h3>
          <p>Dosage: {med.dosage}</p>
          <p>Usage: {med.usage}</p>
          <p>Age Group: {med.ageCategory}</p>
        </div>
      ))}
    </div>
  );
};

export default MedicineList;
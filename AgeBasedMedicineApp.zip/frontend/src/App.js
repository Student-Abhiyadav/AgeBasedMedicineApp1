import React from 'react';
import MedicineList from './components/MedicineList';

function App() {
  return (
    <div className="App">
      <h1>Age Based Medicine App</h1>
      <MedicineList />
    </div>
  );
}

export default App;
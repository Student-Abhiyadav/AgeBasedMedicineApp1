const express = require('express');
const Medicine = require('../models/Medicine');
const jwt = require('jsonwebtoken');
const router = express.Router();

const verifyToken = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1];
  if (!token) return res.status(403).json({ message: 'No token provided' });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch (err) {
    res.status(401).json({ message: 'Unauthorized' });
  }
};

router.get('/', async (req, res) => {
  const meds = await Medicine.find();
  res.json(meds);
});

router.post('/', verifyToken, async (req, res) => {
  const med = new Medicine(req.body);
  await med.save();
  res.json(med);
});

router.put('/:id', verifyToken, async (req, res) => {
  const med = await Medicine.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(med);
});

router.delete('/:id', verifyToken, async (req, res) => {
  await Medicine.findByIdAndDelete(req.params.id);
  res.json({ message: 'Deleted' });
});

module.exports = router;